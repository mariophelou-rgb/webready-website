(function () {
  var dlg = document.getElementById('lead');
  var WA = 'https://wa.me/96176476990?text=';
  function openDlg(ev) {
    if (dlg && typeof dlg.showModal === 'function') {
      ev.preventDefault();
      dlg.showModal();
      var first = dlg.querySelector('input');
      if (first) first.focus();
    }
  }
  Array.prototype.forEach.call(document.querySelectorAll('.js-lead'), function (a) { a.addEventListener('click', openDlg); });
  if (dlg) {
    Array.prototype.forEach.call(dlg.querySelectorAll('[data-close]'), function (b) { b.addEventListener('click', function () { dlg.close(); }); });
    dlg.addEventListener('click', function (e) { if (e.target === dlg) dlg.close(); });
  }
  Array.prototype.forEach.call(document.querySelectorAll('form.lead-form'), function (form) {
    form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      if (!form.reportValidity()) return;
      var company = form.elements.company.value.trim();
      var name = form.elements.name.value.trim();
      var msg = (form.getAttribute('data-wa') || '').replace('{name}', name).replace('{company}', company);
      var url = WA + encodeURIComponent(msg);
      var w = window.open(url, '_blank');
      if (w) { try { w.opener = null; } catch (e) {} } else { window.location.href = url; }
      if (dlg && dlg.open) dlg.close();
    });
  });
})();
